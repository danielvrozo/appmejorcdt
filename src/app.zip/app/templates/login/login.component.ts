import { Component, OnInit} from '@angular/core';

import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { LoginService } from '../../services/api/login.service';
import { LoginPhoneI, LoginCodeI} from '../../modelos/login.interfaces';
import { HttpClient, HttpClientModule, HttpHeaders} from '@angular/common/http'

import { Router} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css', './css/font-family-openSans.css'] 
})
export class LoginComponent implements OnInit {

  sesion:string = "";
  loginFormPhone: FormGroup;
  loginFormCode!: FormGroup;
  formPhone = true;
  formCode = false;
  signUp!: LoginPhoneI;
  signIn!: LoginCodeI;
  loginFormCodeNew: any;

  dataPhone: any = [];

  constructor( private router:Router, public fb: FormBuilder, private http: HttpClient, public api: LoginService ) { 
    this.loginFormPhone = this.fb.group({
      phone_number: ['+573006306922'],
      device_key: ['MY_DEVICE']
    });

  }

  MgsStatus:boolean = false;
  MsgText:any = "";
  classMsg: any = "";

  valueInputSesion: any = "";

  ngOnInit(): void {
    this.checkLocalStorage();
  }

  checkLocalStorage(){
    if(localStorage.getItem('token')){
      this.router.navigate(['dashboard']);
    }
  }

  
  onLoginPhone(){ 

    const formDataValue = this.loginFormPhone.value;

    return this.api.loginByPhone(formDataValue).subscribe((data: any) => {
      this.signUp = data;

      const htppStatusCode = this.signUp.ResponseMetadata.HTTPStatusCode;

      if (htppStatusCode == 200) {
        this.formPhone = false;
        this.formCode = true;

        //Cargamos variables a LocalStorage
        const userSesion = this.signUp.Session;
        const userName = this.signUp.ChallengeParameters.USERNAME;

        localStorage.setItem("sesion", userSesion);
        localStorage.setItem("name", userName);

        this.loginFormCodeNew = this.loginFormCode = this.fb.group({
          answer: [''],
          session: [userSesion],
          username: [userName]
        });
        
      } else {
        this.classMsg = "danger";
        this.MsgText = "Se ha producido un error. Vuelve a intentarlo";
      }
     
    });

  }

  onLoginCode(){ 

    const formDataCodeValue = this.loginFormCodeNew.value;

    return this.api.loginByCode(formDataCodeValue).subscribe((data: any) => {
      this.signIn = data;

      const htppStatusCode = this.signIn.ResponseMetadata.HTTPStatusCode;

      if (htppStatusCode == 200) {

        //Cargamos variables a LocalStorage
        const token = this.signIn.AuthenticationResult.AccessToken;
        const expiration:any  = this.signIn.AuthenticationResult.ExpiresIn;

        localStorage.setItem("token", token);
        localStorage.setItem("expiration", expiration);
        this.router.navigate(["dashboard"]);
        
      } else {
        this.classMsg = "danger";
        this.MsgText = "Se ha producido un error. Vuelve a intentarlo";
      }
     
    });

  }

}
