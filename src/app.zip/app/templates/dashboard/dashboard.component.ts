/* 

mejorCDT - Propiedad intelectual de Luable.app y mejorcdt.com
Project: Interfaz para usuarios - Inicios de Sesión
Sección: Panel administrativo
Varsión: 1.0.0

Lenguaje: Javascript
Framework: Angular 12.2.5
Boostrap: 5

*/
import { Component, OnInit } from '@angular/core';
import { LoginService } from '../../services/api/login.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { codeVerificationI } from '../../modelos/codeVerification.interface'
import { Router} from '@angular/router';
import { ListUserI } from '../../modelos/listaUsuario.interface';
import { animate, state, style, transition, trigger } from '@angular/animations';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap'; 
import * as moment from 'moment';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css', './css/font-family-openSans.css'],
  animations: [
    trigger('widthGrow', [
      state(
        'open',
        style({
          opacity: ""
        })
      ),
      state(
        'closed',
        style({
          opacity: "0",
          marginTop: "-8%"
        })
      ),
      transition('* => *', animate(580))
    ])
  ]
}) 


export class DashboardComponent implements OnInit {

  // Inicio de declaracion de variables   
  user!: ListUserI;
  codeVerifI!: codeVerificationI;
  allCdtUser = 0
  cdtSumAmount: number = 0; 
  cdtSumIf:boolean = false;
  valueHiddenAmount: any = "********";
  moment: any = moment; 
  fechaActual = moment();

  fullname: any = "";
  scoreUser: any;
  avatarUser: any;

  cdts!: any;
    
  constructor( private api:LoginService,  private router:Router, private modal:NgbModal ) { }

  //Inicializador
  ngOnInit(): void {

    this.api.getAllListUser().subscribe((data: any) => {
      this.user = data;
      let cdtsAmountAll = this.user.cdts;
      this.fullname = this.user.fullname;
      this.scoreUser = this.user.score;
      this.avatarUser = this.user.avatar;

      //Se itera para hallar los CDT del usuario
      for (let i = 0; i < cdtsAmountAll.length; i++) { 

        //Si la verificación de código es exitosa, entonces cargara información a la variable, 
        if(localStorage.getItem('verification') == "exit"){
          this.cdtSumAmount += parseInt(this.user.cdts[i].amount);
          
          //cdtSumIf tipo boleean, nos ayudará para mostrar los ***** por si no hay verificación
          //False = No hay verificación
          //True = Hay verificación
          this.cdtSumIf = true;
        } else { 
          //Si no hay verificación, la variable retorna a 0
          this.cdtSumAmount;
        }
      
      }
      //Mapeamos el arreglo de CDT dentro del JSON para buscar cuantos "cdt's" hay
      this.user.cdts.map((dato) => {
        if(dato.bank){
          this.allCdtUser += 1
        }
      })
      
    })   
    //Llamamos las funciones para inicializar 
    this.checkIfVerifiactionLS(); 
    this.checkLoginToken();
  }

  //Para pasar el formato de fecha a letras 
  FechaLetras(dateFun: any, show: any){
    moment.locale('es');
    const date = moment(dateFun);
    const day = date.format('D');
    const month = date.format('MMMM');
    const year = date.format('YYYY');

    if (show == 1) {return day;}
    if (show == 2) {return month;}
    if (show == 3) {return year;}

    return;
  }

  //Funcion para obtener las ganancias total del cdt
  gananciasRoi(amount: any, roi: any){
    const valueRoi = parseInt(roi) - parseInt(amount);
    return valueRoi;
  }

  //Función para separador de miles
  separadorMiles(value: any) {
    return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");;
  } 

  //Formulario para verificiación de código y visualizar los montos
  codeVerForm = new FormGroup({
    codeVfn: new FormControl('', Validators.required)
  })
  
  errorStatus:boolean = false; //Si hay muchos intentos mostrar alert
  succStatus:boolean = false; //Si la verificación es exitosa 
  warnigMsg:any = ""; // Mensaje muchos intentos
  succMsg:any = ""; // Mensaje exitoso
  msgCodeVerification:boolean = true; // Div que contiene el mensaje.
  
  //Entonces una vez enviado el código de verificación y la api nos manda estado 200, lo que hara
  //es guardar una variable en el Local Storage dónde la verificacion será exitosa
  //Luego despues de 2.5segundos se recargará la página y mostrara los valores (amount)
  onVerification(form: codeVerificationI){
    this.api.formVerificationCode(form).subscribe(data => {
      this.codeVerifI = data;
      console.log(data);
      if(this.codeVerifI.status == "200") {
        localStorage.setItem("verification", "exit");
        this.succStatus = true;
        this.succMsg = this.codeVerifI.msg;
        setTimeout(()=>{                         
          window.location.reload();
        }, 2500);
   
      } else {
        this.errorStatus = true;
        this.warnigMsg = this.codeVerifI.msg;
      }
    })
  }
  
  //Si existe la verificacion en LS, el mensaje que nos indica el porque ocultamos los montos desaparecera
  checkIfVerifiactionLS(){
    if(localStorage.getItem('verification') == "exit"){
      this.msgCodeVerification = false;
    }
  }

  //Si llegan a entran a /dashboard sin tener un token, lo llevará al login
  checkLoginToken(){
    if(!localStorage.getItem('token')){
      this.router.navigate(['login']);
    }
  }
  

  //Todo este código para abajo es del modal Bootstrap
  closeResult!: string;

  open(content: any) {
    this.modal.open(content, {centered: true, size: "sm", animation: true, ariaLabelledBy: 'modal-basic-title', windowClass: 'modal-holder',}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  // Mensaje de promoción de código
  state = 'open';
  MsjPromo:boolean = true;

  changeState(){
    if (this.state == 'open') {
      this.state = 'closed';   
    }
  }
}

//Manerá rápido para insertar script de iconos
var script = document.createElement('script');
script.type = 'text/javascript';
script.src = "https://kit.fontawesome.com/749fcedd58.js";
document.body.appendChild(script); 
