export interface ResponseI{
    //Navegación del JSON
    phone_number: string;
    device_key:string; 
}