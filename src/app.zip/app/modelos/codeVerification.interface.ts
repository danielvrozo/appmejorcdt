export interface codeVerificationI{
    status: string;
    msg:string;
}