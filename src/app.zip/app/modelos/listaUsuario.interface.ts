export interface CDTsI {
    bank: string;
    url_cdt: string;
    amount: string;
    roi: number;
    date_open: string;
    date_expiration: string;
    term: string;
    rate: string;

}

export interface statisticsI {
    level: string;
    score: string;

}

export interface ListUserI {
    avatar:string;
    fullname:string;
    level: string;
    score: string;
    cdts:CDTsI[];
}




