import { Injectable } from '@angular/core';
import { HttpClient, HttpClientModule, HttpHeaders} from '@angular/common/http';
import { Observable, throwError  } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { LoginPhoneI, LoginCodeI } from '../../modelos/login.interfaces';
import { ResponseI} from '../../modelos/response.interface';
import { ListUserI } from '../../modelos/listaUsuario.interface';
import { codeVerificationI } from '../../modelos/codeVerification.interface';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  /* url:string = "https://5j3cb83dmd.execute-api.us-east-1.amazonaws.com/test-dev/auth/"; */
  url:string = "https://613a9297110e000017a45346.mockapi.io/api/v1/";

  apiCDT:string = "https://5m221i1mw5.execute-api.us-east-1.amazonaws.com/test-dev/auth/";

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  }

  constructor(private http:HttpClient) { }



  loginByPhone(data: any): Observable<LoginPhoneI> {
    return this.http.post<LoginPhoneI>(this.apiCDT + 'sign_up', JSON.stringify(data), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  loginByCode(data: any): Observable<LoginCodeI> {
    return this.http.post<LoginCodeI>(this.apiCDT + 'sign_in', JSON.stringify(data), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  /* loginByCode(form: LoginCodeI):Observable<ResponseI>{
    let direccion = this.url + "sign_in";
    return this.http.post<ResponseI>(direccion, form);
  } */

  getAllListUser():Observable<ListUserI>{
    let direccion = this.url + "user";
    return this.http.get<ListUserI>(direccion);
  }

  formVerificationCode(form: codeVerificationI):Observable<codeVerificationI>{
    //Code -> Api Check
    //CodeError -> Api Error
    let direccion = this.url + "codeVerification";
    return this.http.post<codeVerificationI>(direccion, form);
  }



  handleError(error: { error: { message: string; }; status: any; message: any; }) {
    let errorMessage = '';
    if(error.error instanceof ErrorEvent) {
      // Get client-side error
      errorMessage = error.error.message;
    } else {
      // Get server-side error
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
 }
}
